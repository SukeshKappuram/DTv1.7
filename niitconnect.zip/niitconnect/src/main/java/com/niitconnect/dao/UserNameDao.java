package com.niitconnect.dao;

import com.niitconnect.model.Users;

public interface UserNameDao {
Users getUserNameByEmail(String username);
}
