package com.niitconnect.service;

import com.niitconnect.model.Users;

public interface UserNameDaoService {
Users getUserNameByEmail(String username);
}
